package interfaz;
import java.util.Random;
import java.util.Scanner;
import java.util.Scanner;
public class main {

public static void main(String[] args) {
		int cantidadBalas = 10000;
        int cantidadCapsulas = 2000;
        int cantidadObjetosinteres = 0;
        int puntos = 0;
        finjuego findeljuego = new finjuego();
	    Scanner sc = new Scanner(System.in);
	    // Preguntar al usuario por el nombre del piloto
        System.out.print("\033[31mIngrese el nombre del piloto:\033[0m");
        String nombrepiloto = sc.nextLine();
        Nave nave = new Nave("comando z ", nombrepiloto, cantidadBalas, cantidadCapsulas, cantidadObjetosinteres);
        nave.imprimirValores();
        logica Logica1 = new logica();
        logica logica2 = new logica();
        logica logica3 = new logica();


         /*esta es la lista de enmigos que genera;
        ("1. Metioritos");
        ("2. Planeta");
        ("3. Planeta con vida");
        ("4. Agujero Negro");*/
      
Random random = new Random();
boolean seguirJugando = true;

do {
    String opcion = sc.nextLine();

if (opcion.equals("q")) {
        seguirJugando = false;
        System.out.println("Juego terminado");
        break;
            }

if (opcion.equals(" ")) {
    	
        int opcionEnemigo = random.nextInt(7) + 1;
        Enemigos enemigo = null;
        
objetos objetos;
switch (opcionEnemigo) {
            case 1:
	enemigo = GeneradorDeEnemigos.generarMetioritosAleatorio();
	 System.out.println("\033[38;2;128;128;128m\n+---------------------------+    +---------------------------+");
	 System.out.println("|           ENEMIGO         |    |             NAVE          |");
	 System.out.println("+---------------------------+    +---------------------------+");
	 System.out.println("|" + enemigo.getNombre() + "           |    | Nombre:"  + nave.getnombre() + " |");
	 System.out.println("| Daño: " +   enemigo.getDaño() + "      |    | Daño: " + nave.getnombrepiloto() + "        |");
	 System.out.println("| Tamaño: " +  enemigo.getTamaño() + "   |    |proximidad del enemigo " + nave.getdistanciaNaveenemigo()+ "      |");
	 System.out.println("| Vida: "  + enemigo.getvida() + "       |    | Vida: " + nave.getdistanciaNaveObjeto() + "   |");
	 nave.actualizarValoresAleatorios();
	 System.out.println("                                  |Velocidad: " + nave.getvelocidadNave()+ "|");
	 System.out.println("                                  |Cantidad de Balas: " + nave.getcantidadBalas()+ "|");
	 System.out.println("                                  |Cantidad de Capsulas: " + nave.getcantidadCapsulas()+ "|");
	 System.out.println("                                  |Cantidad de Objetos de Interes: " + nave.getcantidadObjetosInteres()+ "|");
	 System.out.println("+-----------------------------+    +---------------------------+");
	 puntos=puntos + 100;
	 findeljuego.verificarNaveDestruida(nave);
     logica2.esquivar(nave, enemigo);
	 System.out.println("Presione espacio para crear un enemigo");
	 
     break;
            case 2:
	enemigo = GeneradorDeEnemigos.generarPlanetaAleatorio();
	 System.out.println("\033[38;2;128;0;0m\n+---------------------------+    +---------------------------+");
	 System.out.println("|           ENEMIGO         |    |             NAVE          |");
	 System.out.println("+---------------------------+    +---------------------------+");
	 System.out.println("  " + enemigo.getNombre() + "               |                  |Nombre:"  + nave.getnombre() + " |");
     System.out.println("| Daño: "  + enemigo.getDaño() +  "         |                  |Daño: " + nave.getnombrepiloto() + "        |");
     System.out.println("| Tamaño: " + enemigo.getTamaño()+"         |                  |Tamaño: " + nave.getdistanciaNaveenemigo()+ "      |");
     System.out.println("| Vida: " +  enemigo.getvida() +"           |                  |Vida: " + nave.getdistanciaNaveObjeto() + "   |");
     nave.actualizarValoresAleatorios();
     System.out.println("                                  |Distancia a Nave enemiga: " + nave.getdistanciaNaveenemigo()+ "|");
     System.out.println("                                  |Velocidad: " + nave.getvelocidadNave()+ "|");
     System.out.println("                                  |Cantidad de Balas: " + nave.getcantidadBalas()+ "|");
     System.out.println("                                  |Cantidad de Capsulas: " + nave.getcantidadCapsulas()+ "|");
     System.out.println("                                  |Cantidad de Objetos de Interes: " + nave.getcantidadObjetosInteres()+ "|");
     System.out.println("+-----------------------------+    +---------------------------+");
     System.out.println("Elige una opción:");
     puntos=puntos + 200;
     logica2.esquivar(nave, enemigo);
     findeljuego.verificarNaveDestruida(nave);
     break;

            case 3:
	enemigo = GeneradorDeEnemigos.generarPlanetaVidaAleatorio();
	 System.out.println("\u001B[36m\n+---------------------------+    +---------------------------+");
	 System.out.println("|           ENEMIGO         |    |             NAVE          |");
	 System.out.println("+---------------------------+    +---------------------------+");
	 System.out.println("  " + enemigo.getNombre() + "       |    | Nombre:"  + nave.getnombre() + " |");
     System.out.println("| Daño: "  + enemigo.getDaño() +  " |    | Daño: " + nave.getnombrepiloto() + "        |");
     System.out.println("| Tamaño: " + enemigo.getTamaño()+" |    | Tamaño: " + nave.getdistanciaNaveenemigo()+ "      |");
     System.out.println("| Vida: " +  enemigo.getvida() +"   |      | Vida: " + nave.getdistanciaNaveObjeto() + "   |");
     nave.actualizarValoresAleatorios();
     System.out.println("                                  |Distancia a Nave enemiga: " + nave.getdistanciaNaveenemigo()+ "|");
     System.out.println("                                  |Velocidad: " + nave.getvelocidadNave()+ "|");
     System.out.println("                                  |Cantidad de Balas: " + nave.getcantidadBalas()+ "|");
     System.out.println("                                  |Cantidad de Capsulas: " + nave.getcantidadCapsulas()+ "|");
     System.out.println("                                  |Cantidad de Objetos de Interes: " + nave.getcantidadObjetosInteres()+ "|");
     System.out.println("+-----------------------------+    +---------------------------+");
     puntos=puntos + 300;
     logica3.defensor(nave,enemigo);
     findeljuego.verificarNaveDestruida(nave);
     System.out.println("Presione espacio para crear un enemigo");
                break;
            case 4:
     enemigo = GeneradorDeEnemigos.generarAgujeroNegroAleatorio(); 
     System.out.println("\u001B[32m\n+---------------------------+    +---------------------------+");
	 System.out.println("|           ENEMIGO         |    |             NAVE          |");
	 System.out.println("+---------------------------+    +---------------------------+");
	 System.out.println("  " + enemigo.getNombre() + "               |    | Nombre:"  + nave.getnombre() + " |");
     System.out.println("| Daño: "  + enemigo.getDaño() +  "         |    | Daño: " + nave.getnombrepiloto() + "        |");
     System.out.println("| Tamaño: " + enemigo.getTamaño()+"         |    | Tamaño: " + nave.getdistanciaNaveenemigo()+ "      |");
     System.out.println("| Vida: " +  enemigo.getvida() +"           |    | Vida: " + nave.getdistanciaNaveObjeto() + "   |");
     nave.actualizarValoresAleatorios();
     System.out.println("                                  |Distancia a Nave enemiga: " + nave.getdistanciaNaveenemigo()+ "|");
     System.out.println("                                  |Velocidad: " + nave.getvelocidadNave()+ "|");
     System.out.println("                                  |Cantidad de Balas: " + nave.getcantidadBalas()+ "|");
     System.out.println("                                  |Cantidad de Capsulas: " + nave.getcantidadCapsulas()+ "|");
     System.out.println("                                  |Cantidad de Objetos de Interes: " + nave.getcantidadObjetosInteres()+ "|");
     System.out.println("+-----------------------------+    +---------------------------+");
     puntos=puntos + 300;
     logica2.esquivar(nave, enemigo);
     findeljuego.verificarNaveDestruida(nave);
     System.out.println("Presione espacio para crear un enemigo");
                break;
		    case 5:
	objetos  = GeneradorDeObjetos.generarObjetoClase1Aleatorio();
	System.out.println("\033[0;31m\n+---------------------------+    +---------------------------+");
	System.out.println("|           objeto            |    |             NAVE          |");
	System.out.println("+---------------------------+    +---------------------------+");
	System.out.println("|" + objetos.getNombre()+ "                    |    | Nombre:"  + nave.getnombre() + " |");
	System.out.println("| Tamaño:  " + objetos.gettamaño() + "         |    | distancia objeto: " + nave.getdistanciaNaveObjeto()+ "      |");
	System.out.println("| Vida:  " + objetos.getvida()        +"       |    | Vida: " + nave.getcantidadCapsulas() + "   |");
	nave.actualizarValoresAleatorios();
	System.out.println("                                  |Distancia a Nave enemiga: " + nave.getdistanciaNaveenemigo()+ "|");
	System.out.println("                                  |Velocidad: " + nave.getvelocidadNave()+ "|");
	System.out.println("                                  |Cantidad de Balas: " + nave.getcantidadBalas()+ "|");
	System.out.println("                                  |Cantidad de Capsulas: " + nave.getcantidadCapsulas()+ "|");
	System.out.println("                                  |Cantidad de Objetos de Interes: " + nave.getcantidadObjetosInteres()+ "|");
	 puntos=puntos + 500;
	Logica1.compararDistancias(objetos, nave);	
	findeljuego.verificarNaveDestruida(nave);
	System.out.println("+-----------------------------+    +---------------------------+");
	 break;
	   case 6:
	 objetos = GeneradorDeObjetos.generarObjetoClase2Aleatorio();
	System.out.println("\033[38;2m\n+---------------------------+    +---------------------------+");
	System.out.println("|           objeto            |    |             NAVE          |");
	System.out.println("+---------------------------+    +---------------------------+");
	System.out.println("|" + objetos.getNombre()+ "              |    | Nombre:"  + nave.getnombre() + " |");
	System.out.println("| Tamaño:  " + objetos.gettamaño() + "   |          | distancia objeto: " + nave.getdistanciaNaveObjeto() + "      |");
	System.out.println("| Vida:  " + objetos.getvida()        +" |    | Vida: " + nave.getcantidadCapsulas() + "   |");
	nave.actualizarValoresAleatorios();
	System.out.println("                                  |Distancia a Nave enemiga: " + nave.getdistanciaNaveenemigo()+ "|");
	System.out.println("                                  |Velocidad: " + nave.getvelocidadNave()+ "|");
	System.out.println("                                  |Cantidad de Balas: " + nave.getcantidadBalas()+ "|");
	System.out.println("                                  |Cantidad de Capsulas: " + nave.getcantidadCapsulas()+ "|");
	System.out.println("                                  |Cantidad de Objetos de Interes: " + nave.getcantidadObjetosInteres()+ "|");
	Logica1.compararDistancias(objetos, nave);
	findeljuego.verificarNaveDestruida(nave);

	System.out.println("+-----------------------------+    +---------------------------+");
	   break;
	 case 7:
	objetos = GeneradorDeObjetos.generarObjetoClase3Aleatorio();
	System.out.println("\033[31m\n+---------------------------+    +---------------------------+");
	System.out.println("|           objeto           |    |             NAVE          |");
	System.out.println("+---------------------------+    +---------------------------+");
	System.out.println("|" + objetos.getNombre()+ "|     |Nombre:"  + nave.getnombre() + "|");
	System.out.println("| Tamaño:  " + objetos.gettamaño() + "|                |distancia objeto: " + nave.getdistanciaNaveObjeto()+ "|");
	System.out.println("| Vida:  " + objetos.getvida()+"|                      |Vida: " + nave.getcantidadCapsulas() + "   |");
	nave.actualizarValoresAleatorios();
	System.out.println("                                  |Distancia a enemigo: " + nave.getdistanciaNaveenemigo()+ "|");
	System.out.println("                                  |Velocidad: " + nave.getvelocidadNave()+ "|");
	System.out.println("                                  |Cantidad de Balas: " + nave.getcantidadBalas()+ "|");
	System.out.println("                                  |Cantidad de Capsulas: " + nave.getcantidadCapsulas()+ "|");
	System.out.println("                                  |Cantidad de Objetos de Interes: " + nave.getcantidadObjetosInteres()+ "|");
	  System.out.print(+puntos); 
	  Logica1.compararDistancias(objetos, nave);
	  findeljuego.verificarNaveDestruida(nave);
	   System.out.println("+-----------------------------+    +---------------------------+");
	break; 		
}

if (enemigo != null) {
	System.out.println("\n");
	
}}} 

while (seguirJugando);
System.out.print(+puntos);
}}



    

                
                    
                