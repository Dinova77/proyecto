package interfaz;

import java.util.Random;

public class GeneradorDeEnemigos {

    public static Enemigos generarMetioritosAleatorio() {
        String nombre = "lluvia de metioritos acercandose";
        int daño = 2000;
        Random random = new Random();
        int tamaño = random.nextInt(200) + 1;
        int vida = 50;
        
        return new Metioritos(nombre, daño, tamaño, vida);
    }

    public static Enemigos generarPlanetaAleatorio() {
        String nombre = "Planeta esta osbtruyendo";
        int daño = 2000;
        Random random = new Random();
        int tamaño = random.nextInt(300) + 100;
        int vida = 200;
        return new Planeta(nombre, daño, tamaño, vida);
    }

    public static  Enemigos generarPlanetaVidaAleatorio() {
        String nombre = "Planeta con vida obstryuendo";
        int daño = 2000;
        Random random = new Random();
        int tamaño = random.nextInt(300) + 1;
        int vida =500000;
        return new PlanetaVida(nombre, daño, tamaño, vida);
    }

    public static Enemigos generarAgujeroNegroAleatorio() {
        String nombre = "aproximandose a Agujero Negro";
        Random random = new Random();
        int daño = random.nextInt(350) + 150;
        int tamaño = random.nextInt(500) + 1;
        int vida = 500 ;
        return new AgujeroNegro(nombre,daño,tamaño,vida);
        		}

}