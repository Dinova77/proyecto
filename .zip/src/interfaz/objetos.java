package interfaz;

public abstract class objetos {
    public int vida;
    public String nombre;
    public double tamaño;

    public objetos(int vida, String nombre,double tamaño) {
        this.vida = vida;
        this.nombre = nombre;
        this.tamaño = tamaño;
    }

    // Métodos getters y setters para vida y nombre
    public String getNombre() {
        return nombre;
    }

    public int getvida() {
        return vida;
    }
    public float gettamaño() {
        return (float) tamaño;
    }

}

class ObjetoClase1 extends objetos {
    public ObjetoClase1(String nombre, int vida,double tamaño) {
        super(vida,nombre,tamaño);
    }
}


class ObjetoClase2 extends objetos {
	    public ObjetoClase2(String nombre, int vida,double tamaño) {
	        super(vida, nombre,tamaño);
	    }
	}
class ObjetoClase3 extends objetos {
    public ObjetoClase3(String nombre, int vida,double tamaño) {
        super(vida, nombre,tamaño);
    }
}


