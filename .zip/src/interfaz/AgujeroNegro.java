package interfaz;

public class AgujeroNegro extends Enemigos{
	    public AgujeroNegro(String nombre, int daño, int tamaño, int vida) {
	        super(nombre, daño, tamaño, vida);
	    }

	    @Override
	    public void atacar() {
	        System.out.println("Agujero Negro atacando...");
	    }
	}


