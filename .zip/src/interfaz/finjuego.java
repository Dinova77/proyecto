package interfaz;

public class finjuego {
	public void verificarNaveDestruida(Nave nave) {
	    if (nave.getcantidadBalas() <= 0 || nave.getcantidadCapsulas() <= 0) {
	        boolean seguirjugando = false;
	        System.out.println("Tu nave ha sido destruida. Juego terminado.");
	    }}
	}
