package interfaz;

public class Planeta extends Enemigos{
	    public Planeta(String nombre, int daño, int tamaño, int vida) {
	        super(nombre, daño, tamaño, vida);
	    }

	    @Override
	    public void atacar() {
	        System.out.println("Planeta obstruyendo no presenta vida...");
	    }
	}
