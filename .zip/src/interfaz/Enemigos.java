package interfaz;

public abstract class Enemigos {
    protected String nombre; 
    protected int daño;
    protected int tamaño;
    protected int vida;

    public Enemigos(String nombre, int daño, int tamaño, int vida) {
        this.nombre = nombre;
        this.daño = daño;
        this.tamaño= tamaño;
        this.vida = vida;
    }

    public String getNombre() {
        return nombre;
    }

    public int getDaño() {
        return daño;
    }

    public int getTamaño() {
        return tamaño;
    }

    public int getvida() {
        return vida;
    }

    public abstract void atacar();
}
