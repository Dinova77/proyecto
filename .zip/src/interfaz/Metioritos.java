package interfaz;
public class Metioritos extends Enemigos{
    public Metioritos(String nombre, int daño, int tamaño, int vida) {
        super(nombre, daño, tamaño, vida);
    }

    @Override
    public void atacar() {
        System.out.println("Metiorito atacando...");
    }
}
