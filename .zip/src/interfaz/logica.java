package interfaz;

import java.util.Scanner;

public class logica {

	    public void compararDistancias(objetos objetos, Nave nave) {
	  
	    	
	    	    Scanner scan = new Scanner(System.in);
	    	    System.out.println("¿Qué quieres hacer?");
	    	    System.out.println("1. Esquivar");
	    	    System.out.println("2. Recoger");
	    	    int opc = scan.nextInt();
	    	    
	    	    if (opc == 1) {
	    	        if (nave.getdistanciaNaveObjeto() > objetos.gettamaño()) {
	    	            System.out.println("Se esquivó el objeto. La distancia de la nave es mayor que el tamaño del enemigo.");
	    	        } else {
	    	            System.out.println("El tamaño del enemigo es mayor o igual que la distancia de la nave. ¡Has chocado!");
	    	            nave.cantidadCapsulas = (nave.getcantidadCapsulas()- 200);
	    	        }
	    	    } else if (opc == 2) {
	    	        if (nave.getdistanciaNaveObjeto() > objetos.gettamaño()) {
	    	            System.out.println("Se recogió el objeto. La distancia de la nave es mayor que el tamaño del enemigo.");
	    	           
	    	        } else {
	    	            System.out.println("El tamaño del enemigo es mayor o igual que la distancia de la nave. ¡Has chocado!");
	    	            nave.setCantidadCapsulas(nave.getcantidadCapsulas() - 200);
	    	        }
	    	    }}
	    
public void esquivar( Nave nave, Enemigos enemigo) {
	    	int puntos = 0;
	        System.out.println("Elige una opción:");
	        System.out.println("1. Esquivar");
	        System.out.println("2. Atacar");

	        Scanner scan = new Scanner(System.in);
	        int opc = scan.nextInt();

	        if (opc == 1) {
	            if (enemigo.getTamaño() < nave.getdistanciaNaveenemigo()) {
	                puntos = puntos +  50;
	            
	                System.out.println("pudiste esquivar al enemigo, su tamaño era menor que la distancia a la que se encuentra.");
	            }}
	          if (opc == 2) {
	            if (enemigo.getTamaño() > nave.getdistanciaNaveenemigo()) {
	                nave.setCantidadBalas(nave.getcantidadBalas() - enemigo.getvida());
	                System.out.println("¡Has atacado al enemigo y has infligido " + enemigo.getDaño() + " puntos de daño!");
	                puntos= puntos+enemigo.getDaño();
	            } else {
	                System.out.println("No pudiste esquivar al enemigo, ¡te han atacado!");
	                nave.setCantidadCapsulas(nave.getcantidadCapsulas() - enemigo.getvida());
	            }
	        }
}
	    

public void defensor(Nave nave,Enemigos enemigo) {

    Scanner scan = new Scanner(System.in);
    int opc = scan.nextInt();

    if (opc == 1) {
            System.out.println("pudiste esquivar al enemigo, a la que se encuentra.");
        }
      if (opc == 2) {
            nave.setCantidadBalas(nave.getcantidadBalas() -nave.getcantidadBalas());
            System.out.println("!no puedes atacar un planeta con vida!");
            puntos= puntos+enemigo.getDaño();
        } else {
            System.out.println("No pudiste esquivar al enemigo, ¡te han atacado!");
            nave.setCantidadCapsulas(nave.getcantidadCapsulas() - enemigo.getvida());
        }
    }

}

